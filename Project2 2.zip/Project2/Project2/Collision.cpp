//
//  Collision.cpp
//  Project2
//
//  Created by Divya Madala on 9/26/19.
//  Copyright © 2019 dm3980. All rights reserved.
//

#include "ball.h"
#include "Entity.h"


bool CollisionPlayer(Entity e, Ball b){
    
    float xdist = fabs(e.position.x - b.position.x) ;
    float ydist = fabs(e.position.y - b.position.y);
    
    if (xdist < 0 && ydist < 0){
        return true;
    }
    
    return false;
}

