//
//  ball.hpp
//  Project2
//
//  Created by Divya Madala on 9/26/19.
//  Copyright © 2019 dm3980. All rights reserved.
//

#pragma once
#define GL_SILENCE_DEPRECATION

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "Entity.h"


class Ball {
public:
    
    glm::vec3 position;
    glm::vec3 movement;
    float speed;
    bool stop = false;
    
    GLuint textureID;
    
    Ball();
    
    bool CollisionPlayer(glm::vec3 player);
    void Update(float deltaTime);
    void Render(ShaderProgram *program);
};
